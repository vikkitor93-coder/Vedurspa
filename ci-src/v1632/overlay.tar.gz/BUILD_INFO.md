# Veðurspá 1.6.32 build metadata

Base: verified signed 1.6.31 (vCode 38), target: 1.6.32 (vCode 39). Android package: `is.viktor.vedurspa`. GitHub Actions is the release build authority. No changes to the keystore. See AI_HANDOFF.md for build steps.
