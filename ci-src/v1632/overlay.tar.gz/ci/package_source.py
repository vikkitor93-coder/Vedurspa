"""Create the complete clean source ZIP, excluding generated / temporary files.
Usage: python3 ci/package_source.py /path/to/output.zip
"""
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
INCLUDE_DIRS = ('native-src', 'src', 'public', 'tests', 'ci', 'docs', 'assets', '.github')
INCLUDE_FILES = ('AI_HANDOFF.md', 'README.md', 'BUILD_INFO.md', 'TEST_RESULTS.md', 'index.html',
                 'package.json', 'package-lock.json', 'capacitor.config.json', 'tsconfig.json', 'vite.config.ts', 'GUIDEBOOK.html', 'RELEASE_NOTES_1.6.32.md')
EXCLUDE = {'.git', '__pycache__', 'node_modules', 'dist', 'android', 'web', '.vite'}


def included_files():
    files = [ROOT / name for name in INCLUDE_FILES]
    for folder in INCLUDE_DIRS:
        files.extend(p for p in (ROOT / folder).rglob('*') if p.is_file())
    return sorted({p for p in files if p.is_file() and not
                   any(part in EXCLUDE for part in p.relative_to(ROOT).parts)
                   and p.suffix not in ('.pyc', '.exe', '.apk', '.zip')})


def main(output: Path):
    output.parent.mkdir(parents=True, exist_ok=True)
    with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=8) as archive:
        for f in included_files():
            archive.write(f, f.relative_to(ROOT).as_posix())
    print('Complete source archive:', output, 'files:', len(included_files()))


if __name__ == '__main__':
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'Vedurspa-1.6.21-complete-source.zip')
