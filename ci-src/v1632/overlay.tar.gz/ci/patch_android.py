from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
android = root / 'android'
app_gradle = android / 'app' / 'build.gradle'
s = app_gradle.read_text()
s = re.sub(r'\bversionCode\s+(?:1|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39)\b', 'versionCode 39', s)
s = re.sub(r'\bversionName\s+"(?:1\.0|1\.6|1\.6\.1|1\.6\.2|1\.6\.3|1\.6\.4|1\.6\.5|1\.6\.6|1\.6\.7|1\.6\.8|1\.6\.9|1\.6\.10|1\.6\.11|1\.6\.12|1\.6\.13|1\.6\.14|1\.6\.15|1\.6\.16|1\.6\.17|1\.6\.18|1\.6\.19|1\.6\.20|1\.6\.21|1\.6\.22|1\.6\.23|1\.6\.24|1\.6\.25|1\.6\.26|1\.6\.27|1\.6\.28|1\.6\.29|1\.6\.30|1\.6\.32)"', 'versionName "1.6.32"', s)
if 'vedurspa-debug.keystore' not in s:
    marker = '    buildTypes {'
    signing = '    signingConfigs {\n        debug {\n            storeFile file("vedurspa-debug.keystore")\n            storePassword "android"\n            keyAlias "androiddebugkey"\n            keyPassword "android"\n        }\n    }\n'
    s = s.replace(marker, signing + marker)
if 'androidx.work:work-runtime' not in s:
    needle = "    implementation project(':capacitor-android')\n"
    if needle in s:
        s = s.replace(needle, needle + '    implementation "androidx.work:work-runtime:2.9.1"\n')
    else:
        dep = s.index('dependencies {')
        pos = s.index('\n', dep) + 1
        s = s[:pos] + '    implementation "androidx.work:work-runtime:2.9.1"\n' + s[pos:]
app_gradle.write_text(s)

manifest = android / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
m = manifest.read_text()
for permission in [
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.RECEIVE_BOOT_COMPLETED',
    'android.permission.POST_NOTIFICATIONS',
    'android.permission.REQUEST_INSTALL_PACKAGES',
]:
    if permission not in m:
        m = m.replace('</manifest>', f'    <uses-permission android:name="{permission}" />\n</manifest>')
if 'OfficialForecastActivity' not in m:
    m = m.replace('        <provider\n', '        <activity android:name=".OfficialForecastActivity" android:exported="false" android:configChanges="orientation|screenSize|keyboardHidden" />\n        <provider\n')
if '.updateprovider' not in m:
    provider = ('        <provider android:name=".UpdateFileProvider" '
                'android:authorities="${applicationId}.updateprovider" '
                'android:exported="false" android:grantUriPermissions="true">\n'
                '            <meta-data android:name="android.support.FILE_PROVIDER_PATHS" '
                'android:resource="@xml/vedurspa_update_paths" />\n'
                '        </provider>\n')
    m = m.replace('</application>', provider + '    </application>')
update_paths = android / 'app' / 'src' / 'main' / 'res' / 'xml' / 'vedurspa_update_paths.xml'
update_paths.parent.mkdir(parents=True,exist_ok=True)
update_paths.write_text('<?xml version="1.0" encoding="utf-8"?>\n'
    '<paths xmlns:android="http://schemas.android.com/apk/res/android">\n'
    '  <external-files-path name="updates" path="Download/" />\n'
    '</paths>\n')
manifest.write_text(m)

native_src = root / 'native-src'
target = android / 'app' / 'src' / 'main' / 'java'
for f in native_src.rglob('*.java'):
    rel = f.relative_to(native_src)
    out = target / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(f.read_bytes())

keystore = root / 'ci' / 'vedurspa-debug.keystore'
(android / 'app' / 'vedurspa-debug.keystore').write_bytes(keystore.read_bytes())

# Install the pre-rendered, reviewed Android icon assets.  This avoids a
# runtime Pillow dependency and makes the CI and local builds deterministic.
import shutil
icon_res = root / 'assets' / 'app-icons' / 'android'
res_root = android / 'app' / 'src' / 'main' / 'res'
for source in icon_res.rglob('*.png'):
    destination = res_root / source.relative_to(icon_res)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
for density in ('ic_launcher', 'ic_launcher_round'):
    folder = res_root / 'mipmap-anydpi-v26'
    folder.mkdir(parents=True, exist_ok=True)
    (folder / (density + '.xml')).write_text('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background" />\n    <foreground android:drawable="@drawable/vedurspa_launcher_foreground" />\n</adaptive-icon>\n')
values = res_root / 'values'
values.mkdir(parents=True, exist_ok=True)
(values / 'ic_launcher_background.xml').write_text('<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="ic_launcher_background">#020617</color></resources>\n')
