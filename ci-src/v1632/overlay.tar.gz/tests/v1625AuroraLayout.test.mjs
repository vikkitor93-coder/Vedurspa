import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { NorthernLightsBar } from '../src/components/NorthernLightsBar';
import { LiveNowClock } from '../src/components/LiveNowClock';
import { parseAuroraForecast } from '../src/utils/vedurDirectClient';
const read=name=>readFileSync(new URL('../'+name,import.meta.url),'utf8');
const bar=read('src/components/NorthernLightsBar.tsx');
assert.match(bar,/grid w-full min-w-0 grid-cols-\[/,'compact one-row grid from 1.6.26');
assert.match(bar,/truncate/,'long chosen location must truncate safely');
assert.match(bar,/Besta skyggnið/,'short best-visibility label');
const forecast=parseAuroraForecast(read('tests/fixtures/aurora.html'));
const props={currentFrame:forecast.frames[0],auroraData:forecast.aurora,userLocation:null,
  onSelectLocation(){},onDisableLocation(){},onRequestGps(){},isLocating:false,
  cloudCoverPercent:0,bestTimeInfo:null,onJumpToFrame(){}};
const html=renderToStaticMarkup(React.createElement(NorthernLightsBar,props));
for(const id of ['aurora-status-summary','aurora-daylight-badge','btn-aurora-location-dropdown','btn-best-aurora-tonight']){
  assert.match(html,new RegExp('id="'+id+'"'),`visible control ${id}`);
}
assert.equal((html.match(/<button/g)||[]).length,4,'exactly four aurora controls before opening dialog');
const icon=renderToStaticMarkup(React.createElement(LiveNowClock));
assert.doesNotMatch(icon,/<rect[^>]*fill="white"/,'clock is transparent, not a white sticker');
assert.match(icon,/stroke="#22d3ee"/,'clock uses themed cyan seconds hand');
assert.match(icon,/fill="#0f172a"/,'character masks rotating hands with dark button color');
assert.match(read('src/components/HugeNavButtons.tsx'),/<LiveNowClock \/>/,'Now button keeps real clock');
assert.equal(JSON.parse(read('package.json')).version,'1.6.32');
console.log('v1.6.25 tall 2x2 aurora layout and themed real clock: PASS');
