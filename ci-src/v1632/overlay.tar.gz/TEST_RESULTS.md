# Veðurspá 1.6.32 verification

Local targeted static tests passed: `node tests/v1632ThemesAndGuide.test.mjs`, `node tests/v1630SimpleUpdate.test.mjs`, `node tests/v1631LanguageGuide.test.mjs`, `node tests/v1629NativeUpdate.test.mjs`. `cd ci && GOPROXY=off go test ./...` passed.

Hosted npm install, TypeScript lint, full regressions, Vite build, Android signing/APK and Windows executable: pending until GitHub Actions release.
