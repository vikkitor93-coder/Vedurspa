# Veðurspá 1.6.32 — Guide book, themes and updater refinement

- Six appearance themes: Midnight, Light, Ocean, Forest, Violet and Sunset. Official forecast images remain unchanged.
- Settings top menu shows Settings, Help, Language (globe), Updates; easily found in any selected language.
- New standalone illustrated guide book with flip-through pages, plus in-app Guide Center and flip-book.
- The guided tour now uses stylized pictures based closely on real weather, aurora/cloud, local and 4-map screens.
- Update section stays small and minimizable; when a newer version is available, users can download it. After canceling/not installing now, the installer can be reopened without losing the update action.
- All earlier provider, caching, warnings and map behavior preserved.
