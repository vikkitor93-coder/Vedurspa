import React, { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { BookOpen, CircleHelp,  Sparkles, CloudRain, LayoutGrid, MapPin, X } from 'lucide-react';
import { ui, type AppLanguage } from '../i18n';
import type { AppMode } from '../types';
import type { GuideKind } from './GuidedTour';

interface Props {
  locale: AppLanguage;
  currentMode: AppMode;
  onClose: () => void;
  onOpenTour: (kind: GuideKind) => void;
  onOpenBook: () => void;
}

const modeIcon: Record<AppMode, React.ReactNode> = {
  weather: <CloudRain className="w-4 h-4" />,
  nordurljos: <Sparkles className="w-4 h-4" />,
  stadaspa: <MapPin className="w-4 h-4" />,
  all4: <LayoutGrid className="w-4 h-4" />,
};

const modeLabelKey = {
  weather: 'guideWeather',
  nordurljos: 'guideAurora',
  stadaspa: 'guideStation',
  all4: 'guideAll4',
} as const;

function guideBookLabel(locale: AppLanguage): string {
  return locale === 'is' ? 'Leiðbeiningabók' : 'Guide book';
}

function currentTabLabel(locale: AppLanguage): string {
  return locale === 'is' ? 'Leiðsögn fyrir þennan flipa' : 'Guide for this tab';
}

export const GuideCenter: React.FC<Props> = ({ locale, currentMode, onClose, onOpenTour, onOpenBook }) => {
  const openerRef = useRef<Element | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    openerRef.current = document.activeElement;
    dialogRef.current?.focus();
    return () => {
      if (openerRef.current instanceof HTMLElement) openerRef.current.focus();
    };
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose]);

  return createPortal(
    <div className="fixed inset-0 z-[195] bg-slate-950/86 backdrop-blur-sm p-3 sm:p-4 flex items-center justify-center">
      <div ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true" className="w-full max-w-xl rounded-3xl border border-cyan-500/40 bg-slate-950 text-white shadow-2xl outline-none overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800">
          <CircleHelp className="w-5 h-5 text-cyan-300" />
          <div>
            <div className="font-black text-cyan-100">{ui('guide', locale)}</div>
            <div className="text-xs text-slate-400">{ui('guideHint', locale)}</div>
          </div>
          <button type="button" onClick={onClose} className="ml-auto w-11 h-11 rounded-xl bg-slate-900 border border-slate-700 grid place-items-center">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-4 space-y-3">
          <button type="button" onClick={() => onOpenTour('all')} className="w-full min-h-14 rounded-2xl bg-cyan-600 text-white font-black px-4 py-3 text-left">
            <div>{ui('startTour', locale)}</div>
            <div className="text-xs font-medium text-cyan-50/90 mt-0.5">{ui('tour', locale)}</div>
          </button>
          <button type="button" onClick={() => onOpenTour(currentMode)} className="w-full min-h-12 rounded-2xl bg-slate-900 border border-slate-700 px-4 py-3 flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-xl bg-slate-800 grid place-items-center text-cyan-300">{modeIcon[currentMode]}</div>
            <div>
              <div className="font-bold text-white">{currentTabLabel(locale)}</div>
              <div className="text-xs text-slate-400">{ui(modeLabelKey[currentMode], locale)}</div>
            </div>
          </button>
          <div className="grid grid-cols-2 gap-2">
            {(['weather', 'nordurljos', 'stadaspa', 'all4'] as const).map((mode) => (
              <button key={mode} type="button" onClick={() => onOpenTour(mode)} className="min-h-12 rounded-2xl bg-slate-900 border border-slate-700 px-3 py-3 text-left flex items-center gap-2">
                <span className="text-cyan-300">{modeIcon[mode]}</span>
                <span className="text-sm font-bold text-slate-100">{ui(modeLabelKey[mode], locale)}</span>
              </button>
            ))}
          </div>
          <button type="button" onClick={onOpenBook} className="w-full min-h-12 rounded-2xl bg-slate-900 border border-emerald-500/40 px-4 py-3 flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 grid place-items-center text-emerald-300"><BookOpen className="w-5 h-5" /></div>
            <div>
              <div className="font-bold text-white">{guideBookLabel(locale)}</div>
              <div className="text-xs text-slate-400">{ui('tapToContinue', locale)}</div>
            </div>
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
};
