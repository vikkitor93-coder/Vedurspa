import { version as appVersion } from '../../package.json';
import { ui, SUPPORTED_LANGUAGES } from '../i18n';
import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, BellRing, Bug, ChevronDown, ChevronUp, CircleHelp, Globe2, RefreshCw, Settings, X } from 'lucide-react';
import { AppSettings } from '../utils/appSettings';
import { APP_THEMES } from '../utils/appTheme';
import type { WarningLevel } from '../utils/warnings';
import { getWarningNotificationStatus } from '../utils/warningNotifications';
import { openExternalReleaseLink } from '../utils/externalLink';
import { supportsNativeUpdates, startAndroidUpdate, getAndroidUpdateStatus, openAndroidInstaller, requestAndroidInstallPermission, listenAndroidUpdate, type AndroidUpdateStatus } from '../utils/androidUpdater';
import { compareVersions, fetchLatestRelease, type ReleaseInfo } from '../utils/appUpdate';

interface Props {
  settings: AppSettings;
  warningCount: number;
  hasLocation: boolean;
  onChange: (settings: AppSettings) => void;
  onEnableNotifications: () => void;
  onOpenWarnings: () => void;
  onOpenDeveloper: () => void;
  onOpenGuideCenter: () => void;
  onClose: () => void;
}

type SettingsSection = 'general' | 'language' | 'updates';

function openExternal(url: string): void {
  void openExternalReleaseLink(url).catch((error: unknown) => {
    console.warn('Could not open GitHub release link', error);
  });
}

function pickAsset(release: ReleaseInfo, matcher: (name: string) => boolean) {
  return release.assets.find(asset => matcher(asset.name.toLowerCase()));
}

export const AppSettingsPanel: React.FC<Props> = ({ settings, warningCount, hasLocation, onChange, onEnableNotifications, onOpenWarnings, onOpenDeveloper, onOpenGuideCenter, onClose }) => {
  const [versionTaps, setVersionTaps] = useState(0);
  const [notificationStatus, setNotificationStatus] = useState<string | null>(null);
  const [releaseInfo, setReleaseInfo] = useState<ReleaseInfo | null>(null);
  const [updateLoading, setUpdateLoading] = useState(false);
  const [updateError, setUpdateError] = useState<string | null>(null);
  const [nativeStatus, setNativeStatus] = useState<AndroidUpdateStatus>({ state: 'idle' });
  const [nativeBusy, setNativeBusy] = useState(false);
  const [activeSection, setActiveSection] = useState<SettingsSection>('general');
  const [updateMinimized, setUpdateMinimized] = useState(true);

  useEffect(() => {
    if (!supportsNativeUpdates()) return;
    let active = true;
    let listener: { remove(): Promise<void> } | undefined;
    void getAndroidUpdateStatus().then(status => { if (active) setNativeStatus(status); }).catch(() => {});
    void listenAndroidUpdate(status => { if (active) setNativeStatus(status); }).then(handle => {
      if (active) listener = handle; else void handle.remove();
    }).catch(() => {});
    const poll = window.setInterval(() => {
      if (!active) return;
      void getAndroidUpdateStatus().then(status => { if (active) setNativeStatus(status); }).catch(() => {});
    }, 1200);
    return () => {
      active = false;
      window.clearInterval(poll);
      if (listener) void listener.remove();
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(() => {
      void getWarningNotificationStatus().then(status => {
        if (cancelled || !status) return;
        if (!status.permissionGranted) setNotificationStatus('Android hefur ekki veitt tilkynningaleyfi. Virkjaðu tilkynningar fyrir appið í símastillingum.');
        else if (!status.enabled) setNotificationStatus('Bakgrunnsathugun er óvirk.');
        else if (!status.hasLocation) setNotificationStatus('Engin staðsetning valin. Veldu GPS eða stað til að fá viðvaranir.');
        else if (status.lastError) setNotificationStatus('Síðasta bakgrunnsathugun mistókst: ' + status.lastError + '. Athugaðu netið.');
        else if (!status.lastCheck) setNotificationStatus('Tilkynningar leyfðar. Fyrsta bakgrunnsathugun er í bið.');
        else setNotificationStatus('Tilkynningar virkar · síðasta athugun ' + new Date(status.lastCheck).toLocaleString('is-IS', { timeZone: 'Atlantic/Reykjavik', hour: '2-digit', minute: '2-digit' }));
      }).catch(() => !cancelled && setNotificationStatus('Android tilkynningaþjónusta svarar ekki. Endurræstu appið eftir uppfærslu.'));
    }, 800);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [settings.warningNotifications, hasLocation]);

  const setNotifications = (enabled: boolean) => {
    onChange({ ...settings, warningNotifications: enabled });
    if (enabled) onEnableNotifications();
  };

  const tapVersion = () => {
    if (settings.developerMode) return;
    const next = versionTaps + 1;
    setVersionTaps(next);
    if (next >= 7) {
      onChange({ ...settings, developerMode: true });
      setVersionTaps(0);
    }
  };

  const refreshRelease = async () => {
    setUpdateLoading(true);
    setUpdateError(null);
    try {
      const release = await fetchLatestRelease();
      setReleaseInfo(release);
    } catch (error) {
      setUpdateError(error instanceof Error ? error.message : 'Ekki tókst að sækja útgáfuupplýsingar.');
    } finally {
      setUpdateLoading(false);
    }
  };

  useEffect(() => {
    void refreshRelease();
  }, []);

  const updateStatus = useMemo(() => {
    if (!releaseInfo) return null;
    const cmp = compareVersions(releaseInfo.version, appVersion);
    if (cmp > 0) return { kind: 'newer' as const, text: `Ný útgáfa tiltæk: ${releaseInfo.version}` };
    if (cmp < 0) return { kind: 'ahead' as const, text: `Þú ert á nýrri útgáfu (${appVersion})` };
    return { kind: 'current' as const, text: 'Þú ert á nýjustu útgáfu.' };
  }, [releaseInfo]);

  useEffect(() => {
    if (updateStatus?.kind === 'newer' || nativeStatus.state === 'downloaded' || nativeStatus.state === 'install_prompt') {
      setUpdateMinimized(false);
    }
  }, [updateStatus?.kind, nativeStatus.state]);

  const installNativeUpdate = async () => {
    if (!apkAsset || !releaseInfo) return;
    setUpdateError(null);
    setNativeBusy(true);
    try {
      const status = await startAndroidUpdate(apkAsset.browser_download_url, releaseInfo.version, apkAsset.size || 0);
      setNativeStatus(status);
      setUpdateMinimized(false);
    } catch (error) {
      setNativeStatus({ state: 'error', message: error instanceof Error ? error.message : 'Niðurhal mistókst.' });
    } finally {
      setNativeBusy(false);
    }
  };

  const promptInstall = async () => {
    setNativeBusy(true);
    try {
      setNativeStatus(await openAndroidInstaller());
      setUpdateMinimized(false);
    } catch (error) {
      setNativeStatus({ state: 'error', message: error instanceof Error ? error.message : 'Ekki tókst að opna uppsetningu.' });
    } finally {
      setNativeBusy(false);
    }
  };

  useEffect(() => {
    if (!supportsNativeUpdates() || nativeStatus.state !== 'downloaded') return;
    void openAndroidInstaller().then(setNativeStatus).catch(error => {
      setNativeStatus({ state: 'error', message: error instanceof Error ? error.message : 'Ekki tókst að opna uppsetningu.' });
    });
  }, [nativeStatus.state]);

  const grantInstallPermission = async () => {
    try {
      await requestAndroidInstallPermission();
    } catch (error) {
      setNativeStatus({ state: 'error', message: error instanceof Error ? error.message : 'Ekki tókst að opna leyfisstillingar.' });
    }
  };

  const dismissInstallerPrompt = () => {
    setNativeStatus((current) => current.state === 'install_prompt' ? { ...current, state: 'downloaded' } : current);
  };

  const apkAsset = releaseInfo ? pickAsset(releaseInfo, name => name.endsWith('.apk')) : undefined;
  const pcAsset = releaseInfo ? pickAsset(releaseInfo, name => name.includes('pc') && name.endsWith('.zip')) : undefined;

  return (
    <div className="fixed inset-0 z-[90] bg-slate-950 text-slate-100 flex flex-col">
      <div className="min-h-14 px-3 border-b border-slate-800 flex items-center gap-2 shrink-0">
        <Settings className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-black flex-1">{ui('settings', settings.language)}</h2>
        <button onClick={onClose} className="w-11 h-11 grid place-items-center rounded-xl border border-slate-700 bg-slate-900"><X className="w-5 h-5" /></button>
      </div>

      <div className="px-3 pt-2 border-b border-slate-900 shrink-0 bg-slate-950/95">
        <div className="grid grid-cols-4 gap-2 max-w-2xl mx-auto">
          <button type="button" onClick={() => setActiveSection('general')} className={`min-h-11 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${activeSection === 'general' ? 'bg-blue-600 border-blue-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'}`}>
            <Settings className="w-4 h-4" />
            {ui('settings', settings.language)}
          </button>
          <button type="button" onClick={onOpenGuideCenter} className="min-h-11 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 bg-slate-900 border-cyan-700/70 text-cyan-100">
            <CircleHelp className="w-4 h-4" />
            {ui('guide', settings.language)}
          </button>
          <button type="button" onClick={() => setActiveSection('language')} className={`min-h-11 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${activeSection === 'language' ? 'bg-emerald-600 border-emerald-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'}`}>
            <Globe2 className="w-4 h-4" />
            {ui('language', settings.language)}
          </button>
          <button type="button" onClick={() => { setActiveSection('updates'); setUpdateMinimized(false); }} className={`min-h-11 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 ${activeSection === 'updates' ? 'bg-cyan-700 border-cyan-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-300'}`}>
            <RefreshCw className="w-4 h-4" />
            {ui('updates', settings.language)}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 max-w-2xl w-full mx-auto space-y-3">
        {activeSection === 'language' && (
          <section id="settings-language" className="rounded-xl border border-cyan-800/70 bg-slate-900/80 p-3 space-y-2">
            <div className="flex items-center gap-2 text-cyan-100 font-bold"><Globe2 className="w-4 h-4" />{ui('language', settings.language)}</div>
            <select id="language-select" value={settings.language} onChange={e => onChange({ ...settings, language: e.target.value as AppSettings['language'] })} className="w-full min-h-11 bg-slate-950 rounded-lg border border-slate-600 p-2 text-white">
              {SUPPORTED_LANGUAGES.map(lang => <option key={lang.tag} value={lang.tag}>{lang.nativeName}</option>)}
            </select>
            <p className="text-xs text-slate-400">{ui('languageNote', settings.language)}</p>
          </section>
        )}

        {activeSection === 'general' && (
          <>
            <section id="settings-themes" className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
              <div className="font-bold mb-2 text-slate-100">{settings.language === 'is' ? 'Útlit og litir' : 'Appearance & colors'}</div>
              <div className="grid grid-cols-3 gap-2">
                {APP_THEMES.map(theme => (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => onChange({ ...settings, theme: theme.id })}
                    aria-pressed={settings.theme === theme.id}
                    className={`min-h-16 rounded-xl border-2 p-2 flex flex-col items-center justify-center gap-1 ${settings.theme === theme.id ? 'border-cyan-400 ring-2 ring-cyan-400/30' : 'border-slate-700'}`}
                    title={theme.label}
                  >
                    <span className="w-9 h-5 rounded-full border border-slate-400/40 shrink-0" style={{ background: `linear-gradient(120deg, ${theme.swatch} 0 62%, ${theme.accent} 62% 100%)` }} />
                    <span className="text-[11px] font-bold text-slate-200">{theme.label}</span>
                  </button>
                ))}
              </div>
            </section>
            <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
              <div className="flex items-center justify-between gap-4">
                <div><div className="font-bold">Sýna veðurviðvaranir efst</div><div className="text-xs text-slate-400 mt-0.5">Litaborði birtist á aðalskjánum þegar virk viðvörun er í gildi.</div></div>
                <button role="switch" aria-checked={settings.showWarnings} onClick={() => onChange({ ...settings, showWarnings: !settings.showWarnings })} className={`w-14 h-8 rounded-full p-1 transition-colors shrink-0 ${settings.showWarnings ? 'bg-blue-600' : 'bg-slate-700'}`}><span className={`block w-6 h-6 rounded-full bg-white transition-transform ${settings.showWarnings ? 'translate-x-6' : 'translate-x-0'}`} /></button>
              </div>
            </section>

            <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-3">
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0"><div className="font-bold flex items-center gap-2"><BellRing className="w-4 h-4 text-yellow-300" />Tilkynningar um veðurviðvaranir</div><div className="text-xs text-slate-400 mt-0.5">Bakgrunnsathugun á Android. Tilkynning er aðeins send þegar valinn staður er innan viðvörunarsvæðis.</div></div>
                <button role="switch" aria-checked={settings.warningNotifications} onClick={() => setNotifications(!settings.warningNotifications)} className={`w-14 h-8 rounded-full p-1 transition-colors shrink-0 ${settings.warningNotifications ? 'bg-blue-600' : 'bg-slate-700'}`}><span className={`block w-6 h-6 rounded-full bg-white transition-transform ${settings.warningNotifications ? 'translate-x-6' : 'translate-x-0'}`} /></button>
              </div>
              {notificationStatus && <div role="status" className="mt-2 rounded-lg border border-slate-700 bg-slate-950/80 px-3 py-2 text-xs text-slate-200">{notificationStatus}</div>}
              {!hasLocation && settings.warningNotifications && <div className="mt-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-2 py-1.5 text-xs text-amber-200">Veldu staðsetningu eða GPS svo appið viti hvaða viðvaranir eiga við þig.</div>}
              <div className="mt-3"><div className="text-xs font-bold text-slate-300 mb-1">Lágmarksstig tilkynningar</div><div className="grid grid-cols-3 gap-2">{([['yellow', 'Gul'], ['orange', 'Appelsínugul'], ['red', 'Rauð']] as Array<[WarningLevel, string]>).map(([level, label]) => <button key={level} onClick={() => onChange({ ...settings, warningNotificationMinLevel: level })} className={`min-h-11 rounded-xl border px-2 py-2 text-xs font-black ${settings.warningNotificationMinLevel === level ? (level === 'yellow' ? 'bg-yellow-400 text-slate-950 border-yellow-200' : level === 'orange' ? 'bg-orange-500 text-white border-orange-300' : 'bg-red-600 text-white border-red-300') : 'bg-slate-950 border-slate-700 text-slate-400'}`}>{label}</button>)}</div></div>
            </section>

            <button onClick={onOpenWarnings} className="w-full min-h-14 rounded-xl border border-slate-700 bg-slate-900 p-3 flex items-center gap-3 text-left touch-manipulation"><AlertTriangle className="w-5 h-5 text-yellow-400" /><div className="flex-1"><div className="font-bold">Viðvaranir og veðurfréttir</div><div className="text-xs text-slate-400">{warningCount ? `${warningCount} virk viðvörun${warningCount === 1 ? '' : 'ar'}` : 'Engar virkar viðvaranir'}</div></div><span className="text-slate-500 text-xl">›</span></button>
          </>
        )}

        <section id="settings-update" className="rounded-xl border border-cyan-900/60 bg-cyan-950/25 p-3 space-y-2">
          <div className="flex items-center gap-3">
            <RefreshCw className="w-5 h-5 shrink-0 text-cyan-300" />
            <div className="flex-1 min-w-0">
              <div className="font-bold text-cyan-100">Uppfærslur</div>
              <div className="text-sm text-cyan-200">Útgáfa {appVersion}</div>
              {updateStatus?.kind === 'newer' && <div className="text-xs font-bold text-emerald-300">Ný útgáfa {releaseInfo?.version}</div>}
            </div>
            <button type="button" onClick={() => setUpdateMinimized(value => !value)} className="w-10 h-10 rounded-xl border border-cyan-700/60 bg-slate-900/70 grid place-items-center">
              {updateMinimized ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
            </button>
          </div>
          {!updateMinimized && (
            <>
              {updateError && <p role="alert" className="text-sm text-rose-200">{updateError}</p>}
              {nativeStatus.state === 'error' && <p role="alert" className="text-sm text-rose-200">{nativeStatus.message || 'Uppfærsla mistókst.'}</p>}
              {nativeStatus.state === 'downloading' && <p role="status" className="text-sm text-cyan-200">Sæki uppfærslu í bakgrunni…</p>}
              {updateStatus && <div className="text-xs text-slate-300">{updateStatus.text}</div>}
              {nativeStatus.state === 'permission_required' ? (
                <button type="button" onClick={() => void grantInstallPermission()} className="w-full min-h-11 rounded-xl bg-amber-600 text-white font-bold">Veita uppsetningarleyfi</button>
              ) : nativeStatus.state === 'downloaded' && supportsNativeUpdates() ? (
                <button type="button" onClick={() => void promptInstall()} className="w-full min-h-11 rounded-xl bg-emerald-700 text-white font-bold">Opna uppsetningu</button>
              ) : nativeStatus.state === 'install_prompt' ? (
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => void promptInstall()} className="min-h-11 rounded-xl bg-emerald-700 text-white font-bold">Uppfæra núna</button>
                  <button type="button" onClick={dismissInstallerPrompt} className="min-h-11 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 font-bold">Ekki núna</button>
                </div>
              ) : updateStatus?.kind === 'newer' && supportsNativeUpdates() && apkAsset ? (
                <button id="btn-install-update-now" type="button" onClick={() => void installNativeUpdate()} disabled={nativeBusy || nativeStatus.state === 'downloading'} className="w-full min-h-11 rounded-xl bg-emerald-600 text-white font-black disabled:opacity-60">Uppfæra í {releaseInfo?.version}</button>
              ) : updateStatus?.kind === 'newer' && !supportsNativeUpdates() && pcAsset ? (
                <button id="btn-install-update-now" type="button" onClick={() => openExternal(pcAsset.browser_download_url)} className="w-full min-h-11 rounded-xl bg-cyan-700 text-white font-bold">Sækja uppfærslu {releaseInfo?.version}</button>
              ) : (
                <button id="btn-check-updates" type="button" onClick={() => void refreshRelease()} disabled={updateLoading} className="w-full min-h-11 rounded-xl bg-cyan-700 text-white font-bold disabled:opacity-60">{updateLoading ? ui('checking', settings.language) : ui('checkUpdate', settings.language)}</button>
              )}
            </>
          )}
        </section>

        {activeSection === 'updates' && updateMinimized && (
          <button type="button" onClick={() => setUpdateMinimized(false)} className="w-full min-h-11 rounded-xl border border-cyan-800/60 bg-slate-900 text-cyan-100 font-bold">
            {ui('updates', settings.language)}
          </button>
        )}

        {settings.developerMode && activeSection === 'general' && <section className="rounded-xl border border-fuchsia-900/50 bg-fuchsia-950/20 p-3">
          <div className="font-bold flex items-center gap-2"><Bug className="w-4 h-4 text-fuchsia-400" />Þróunarhamur virkur</div>
          <div className="text-xs text-slate-400 mt-1">Prófunarviðvaranir, prófunarfréttir og próftilkynningar eru aðeins aðgengilegar hér inni.</div>
          <div className="grid grid-cols-2 gap-2 mt-3">
            <button onClick={onOpenDeveloper} className="min-h-11 rounded-xl border border-fuchsia-500/40 bg-fuchsia-500/10 px-3 py-2 text-sm font-black text-fuchsia-200">Opna prófunartæki</button>
            <button onClick={() => onChange({ ...settings, developerMode: false })} className="min-h-11 rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm font-bold text-slate-300">Slökkva á dev</button>
          </div>
        </section>}

        <section className="rounded-xl border border-slate-800 bg-slate-900/50 p-3 text-xs text-slate-400 leading-relaxed">Gögn: Veðurstofa Íslands. Viðvaranir, staðaspár og veðurfréttir eru sóttar beint frá vedur.is og geta verið sýndar úr geymslu ef nettenging bregst.</section>

        <button onClick={tapVersion} className="w-full min-h-11 text-center text-[11px] text-slate-600 select-none">Veðurspá {appVersion}{settings.developerMode ? ' · DEV' : ''}</button>
      </div>
    </div>
  );
};
