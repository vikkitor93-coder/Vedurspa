import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, ArrowRight, BookOpen, X } from 'lucide-react';
import { ui, type AppLanguage } from '../i18n';

const illustrations = {
  weather: '/guide/weather.webp',
  nordurljos: '/guide/aurora.webp',
  stadaspa: '/guide/station.webp',
  all4: '/guide/all4.webp',
} as const;

type Page = {
  image: keyof typeof illustrations;
  title: string;
  body: string;
};

function guideBookLabel(locale: AppLanguage): string {
  return locale === 'is' ? 'Leiðbeiningabók' : 'Guide book';
}

function doneHint(locale: AppLanguage): string {
  return locale === 'is' ? 'Flettu í gegnum blaðsíðurnar með örvunum.' : 'Flip through the pages with the arrows.';
}

function makePages(locale: AppLanguage): Page[] {
  return [
    {
      image: 'weather',
      title: ui('welcomeTitle', locale),
      body: `${ui('welcomeText', locale)} ${doneHint(locale)}`,
    },
    {
      image: 'weather',
      title: ui('weatherTitle', locale),
      body: `${ui('weatherText', locale)} ${ui('weatherLayersText', locale)} ${ui('timelineText', locale)}`,
    },
    {
      image: 'nordurljos',
      title: ui('auroraTitle', locale),
      body: `${ui('auroraText', locale)} ${ui('auroraControlsText', locale)}`,
    },
    {
      image: 'stadaspa',
      title: ui('stationTitle', locale),
      body: ui('stationText', locale),
    },
    {
      image: 'all4',
      title: ui('all4Title', locale),
      body: ui('all4Text', locale),
    },
  ];
}

interface Props {
  locale: AppLanguage;
  onClose: () => void;
}

export const GuideBook: React.FC<Props> = ({ locale, onClose }) => {
  const pages = makePages(locale);
  const [index, setIndex] = useState(0);
  const openerRef = useRef<Element | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    openerRef.current = document.activeElement;
    dialogRef.current?.focus();
    return () => {
      if (openerRef.current instanceof HTMLElement) openerRef.current.focus();
    };
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
      }
      if (event.key === 'ArrowRight') {
        event.preventDefault();
        setIndex((value) => Math.min(value + 1, pages.length - 1));
      }
      if (event.key === 'ArrowLeft') {
        event.preventDefault();
        setIndex((value) => Math.max(value - 1, 0));
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [onClose, pages.length]);

  const page = pages[index];

  return createPortal(
    <div className="fixed inset-0 z-[200] bg-slate-950/88 backdrop-blur-sm p-3 sm:p-4 flex items-center justify-center">
      <div
        ref={dialogRef}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        className="w-full max-w-3xl max-h-[95vh] overflow-hidden rounded-3xl border border-cyan-500/40 bg-slate-950 text-white shadow-2xl outline-none flex flex-col"
      >
        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-800 shrink-0">
          <BookOpen className="w-5 h-5 text-cyan-300" />
          <div className="font-black text-cyan-100">{guideBookLabel(locale)}</div>
          <div className="ml-auto text-xs text-slate-400">{index + 1} / {pages.length}</div>
          <button type="button" onClick={onClose} className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-700 grid place-items-center">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          <img src={illustrations[page.image]} alt="" className="w-full rounded-2xl border border-slate-700 bg-slate-900 object-cover" />
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-cyan-100">{page.title}</h2>
            <p className="mt-2 text-sm sm:text-base leading-relaxed text-slate-200">{page.body}</p>
          </div>
          <div className="grid grid-cols-5 gap-2">
            {pages.map((item, pageIndex) => (
              <button
                key={pageIndex}
                type="button"
                onClick={() => setIndex(pageIndex)}
                className={`rounded-xl overflow-hidden border ${pageIndex === index ? 'border-cyan-400 bg-cyan-500/10' : 'border-slate-700 bg-slate-900'}`}
                aria-label={`${guideBookLabel(locale)} ${pageIndex + 1}`}
              >
                <img src={illustrations[item.image]} alt="" className="w-full h-16 object-cover opacity-90" />
              </button>
            ))}
          </div>
        </div>
        <div className="px-4 py-3 border-t border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <button type="button" onClick={() => setIndex((value) => Math.max(value - 1, 0))} disabled={index === 0} className="min-h-11 px-4 rounded-xl bg-slate-900 border border-slate-700 disabled:opacity-40 flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" />
            {ui('back', locale)}
          </button>
          <div className="text-xs text-slate-400 text-center px-2">{ui('doneMessage', locale)}</div>
          <button type="button" onClick={() => index === pages.length - 1 ? onClose() : setIndex((value) => Math.min(value + 1, pages.length - 1))} className="min-h-11 px-4 rounded-xl bg-cyan-600 text-white font-bold flex items-center gap-2">
            {index === pages.length - 1 ? ui('done', locale) : ui('next', locale)}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
};
