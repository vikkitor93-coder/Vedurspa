/** UI-only palette. Does not recolor official weather maps or provider images. */
export const APP_THEMES = [
  { id: 'midnight', label: 'Midnight', swatch: '#071126', accent: '#2563eb' },
  { id: 'light', label: 'Light', swatch: '#edf4ff', accent: '#2563eb' },
  { id: 'ocean', label: 'Ocean', swatch: '#062b3c', accent: '#0ea5e9' },
  { id: 'forest', label: 'Forest', swatch: '#072b25', accent: '#10b981' },
  { id: 'violet', label: 'Violet', swatch: '#26143d', accent: '#8b5cf6' },
  { id: 'sunset', label: 'Sunset', swatch: '#381b2a', accent: '#f97316' },
] as const;
export type AppTheme = typeof APP_THEMES[number]['id'];
export function isAppTheme(value: unknown): value is AppTheme {
  return APP_THEMES.some(theme => theme.id === value);
}
export function applyAppTheme(value: AppTheme): void {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.appTheme = value;
  document.documentElement.style.colorScheme = value === 'light' ? 'light' : 'dark';
}
