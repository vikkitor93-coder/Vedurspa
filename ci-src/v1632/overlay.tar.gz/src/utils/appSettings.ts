import { isAppTheme, type AppTheme } from './appTheme';
import { SUPPORTED_LANGUAGES, type AppLanguage } from '../i18n';
import type { WarningLevel } from './warnings';

export interface AppSettings {
  showWarnings: boolean;
  warningNotifications: boolean;
  warningNotificationMinLevel: WarningLevel;
  developerMode: boolean;
  language: AppLanguage;
  theme: AppTheme;
}

const KEY = 'vedurspa-app-settings-v2';
const DEFAULTS: AppSettings = {
  showWarnings: true,
  warningNotifications: false,
  warningNotificationMinLevel: 'yellow',
  developerMode: false,
  language: "is",
  theme: "midnight",
};

export function readAppSettings(): AppSettings {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '{}');
    const level = ['yellow','orange','red'].includes(raw.warningNotificationMinLevel) ? raw.warningNotificationMinLevel : 'yellow';
    return {
      ...DEFAULTS,
      ...raw,
      showWarnings: raw.showWarnings !== false,
      warningNotifications: raw.warningNotifications === true,
      warningNotificationMinLevel: level,
      developerMode: raw.developerMode === true,
      language: SUPPORTED_LANGUAGES.some(item=>item.tag===raw.language)?raw.language:"is",
      theme: isAppTheme(raw.theme) ? raw.theme : DEFAULTS.theme,
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export function writeAppSettings(settings: AppSettings): void {
  try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch { /* ignore */ }
}
