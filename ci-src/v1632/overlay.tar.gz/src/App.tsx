import { locationAccess, locationErrorMessage } from './utils/locationPermission';
import { Geolocation } from "@capacitor/geolocation";
import { preloadImage } from "./utils/nativeNetwork";
import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { AppMode, ForecastData, ForecastFrame, UserLocation, All4ForecastData } from "./types";
import { CompactHeader } from "./components/CompactHeader";
import { NorthernLightsBar } from "./components/NorthernLightsBar";
import { MapDisplay } from "./components/MapDisplay";
import { All4MapsDisplay } from "./components/All4MapsDisplay";
import { TimelineSlider } from "./components/TimelineSlider";
import { HugeNavButtons } from "./components/HugeNavButtons";
import { PRESET_LOCATIONS, coordsToMapPercent } from "./utils/locationCoordinates";
import { sampleCloudCoverage } from "./utils/cloudSampler";
import { fetchStationForecastData, StationForecastData } from "./utils/stationForecast";
import { estimateCloudAtLocation, findBestAuroraFrameFromStations } from "./utils/locationWeather";

import { OfflineIndicator } from "./components/OfflineIndicator";
import { StationForecastPanel } from "./components/StationForecastPanel";
import { WarningBanner } from "./components/WarningBanner";
import { WarningsPanel } from "./components/WarningsPanel";
import { GuidedTour, hasCompletedGuide, markGuideComplete, type GuideKind } from "./components/GuidedTour";
import { GuideCenter } from "./components/GuideCenter";
import { GuideBook } from "./components/GuideBook";
import { AppSettingsPanel } from "./components/AppSettingsPanel";
import { readAppSettings, writeAppSettings } from "./utils/appSettings";
import { applyAppTheme } from "./utils/appTheme";
import { fetchWeatherWarnings, WeatherWarningsData, WarningLevel } from "./utils/warnings";
import { fetchWeatherArticles, WeatherArticlesData } from "./utils/weatherArticles";
import { DeveloperPanel } from "./components/DeveloperPanel";
import { DevWarningLevel, makeDevWarnings } from "./utils/devFixtures";
import { configureWarningNotifications, requestWarningNotificationPermission, sendWarningTestNotification } from "./utils/warningNotifications";
import {
  fetchDirectWeatherForecast,
  fetchDirectAuroraForecast,
  fetchDirectAll4Forecast,
  preloadAllForecasts,type OfflineMapStatus,
} from "./utils/vedurDirectClient";

function findClosestFrame(frames: ForecastFrame[] | undefined, targetIso: string): ForecastFrame | null {
  if (!frames || frames.length === 0) return null;
  if (!targetIso) return frames[0];
  const targetTime = new Date(targetIso).getTime();
  let closest = frames[0];
  let minDiff = Math.abs(new Date(closest.timestamp).getTime() - targetTime);
  for (let i = 1; i < frames.length; i++) {
    const diff = Math.abs(new Date(frames[i].timestamp).getTime() - targetTime);
    if (diff < minDiff) {
      minDiff = diff;
      closest = frames[i];
    }
  }
  return closest;
}

export default function App() {
  const [data, setData] = useState<ForecastData | null>(null);
  const [all4Data, setAll4Data] = useState<All4ForecastData | null>(null);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  // Default to Rain forecast (weather mode, urkoma) as requested
  const [stationMounted,setStationMounted]=useState(false);
  const [forecastMode, setForecastMode] = useState<AppMode>("weather");
  const [selectedCategory, setSelectedCategory] = useState<string>("urkoma");
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [offlineMaps,setOfflineMaps]=useState<OfflineMapStatus|null>(null);
  const lastOfflineReport=useRef(0);
  const reportOfflineMaps=useCallback((status:OfflineMapStatus)=>{const now=Date.now();if(!status.loading||now-lastOfflineReport.current>=250){lastOfflineReport.current=now;setOfflineMaps(status);}},[]);
  useEffect(()=>{
    let active=true;
    const warm=(force=false)=>{if(!navigator.onLine)return;void preloadAllForecasts(status=>{if(active)reportOfflineMaps(status);},force).catch(()=>{if(active)setOfflineMaps({total:0,ready:0,failed:1,loading:false});});};
    warm();
    void fetchDirectAll4Forecast().then(value=>{if(active)setAll4Data(value);}).catch(()=>{});
    // National station data also supports the automatic offline Staðaspá fallback.
    void fetchStationForecastData().then(value=>{if(active)setStationCloudData(value);}).catch(()=>{});
    const online=()=>warm(true);
    const visible=()=>{if(document.visibilityState==='visible')warm();};
    const timer=window.setInterval(visible,5*60*1000);
    window.addEventListener('online',online);document.addEventListener('visibilitychange',visible);
    return()=>{active=false;clearInterval(timer);window.removeEventListener('online',online);document.removeEventListener('visibilitychange',visible);};
  },[reportOfflineMaps]);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [appSettings, setAppSettings] = useState(readAppSettings);
  useEffect(() => { applyAppTheme(appSettings.theme); }, [appSettings.theme]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [guideKind, setGuideKind] = useState<GuideKind|null>(null);
  const [guideCenterOpen, setGuideCenterOpen] = useState(false);
  const [guideBookOpen, setGuideBookOpen] = useState(false);
  useEffect(()=>{if(hasCompletedGuide())return;const timer=window.setTimeout(()=>setGuideKind('all'),1700);return()=>window.clearTimeout(timer);},[]);
  const [warningsOpen, setWarningsOpen] = useState(false);
  const [warningFromBanner, setWarningFromBanner] = useState(false);
  const [warningsData, setWarningsData] = useState<WeatherWarningsData | null>(null);
  const [warningsError, setWarningsError] = useState<string | null>(null);
  const [warningsLoading, setWarningsLoading] = useState(false);
  const [newsData, setNewsData] = useState<WeatherArticlesData | null>(null);
  const [newsError, setNewsError] = useState<string | null>(null);
  const [newsLoading, setNewsLoading] = useState(false);
  const [developerOpen, setDeveloperOpen] = useState(false);
  const [devWarningLevel, setDevWarningLevel] = useState<DevWarningLevel>("off");
  const [devArticles, setDevArticles] = useState(false);
  const [stationRefreshToken, setStationRefreshToken] = useState(0);
  const [stationHeaderTimestamp, setStationHeaderTimestamp] = useState<string | null>(null);

  // Native Android back delegates to this single navigation stack. Child map/detail
  // panels get first chance to consume it before any page/overlay is dismissed.
  const uiBackRef=useRef<()=>boolean>(()=>false);
  uiBackRef.current=()=>{
    if(guideBookOpen){setGuideBookOpen(false);return true;}
    if(guideCenterOpen){setGuideCenterOpen(false);return true;}
    if(guideKind){markGuideComplete();setGuideKind(null);return true;}
    if(developerOpen){setDeveloperOpen(false);setSettingsOpen(true);return true;}
    if(settingsOpen){setSettingsOpen(false);return true;}
    if(warningsOpen){
      const warningBack=new Event('vedurspa:warnings-back',{cancelable:true});
      window.dispatchEvent(warningBack);
      if(warningBack.defaultPrevented)return true;
      setWarningsOpen(false);return true;
    }
    const backEvent=new Event('vedurspa:navigate-back',{cancelable:true});
    window.dispatchEvent(backEvent);
    if(backEvent.defaultPrevented)return true;
    if(forecastMode!=='weather'){setForecastMode('weather');return true;}
    return false;
  };
  useEffect(()=>{
    const back=()=>uiBackRef.current();
    (window as Window & {vedurspaHandleBack?:()=>boolean}).vedurspaHandleBack=back;
    const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'&&back()){e.preventDefault();e.stopPropagation();}};
    window.addEventListener('keydown',escape,true);
    return()=>{window.removeEventListener('keydown',escape,true);delete (window as Window & {vedurspaHandleBack?:()=>boolean}).vedurspaHandleBack;};
  },[]);

  // User location & cloud evaluation
  const [userLocation, setUserLocation] = useState<UserLocation | null>(() => {
    try {
      if (localStorage.getItem("vedurspa-location-enabled") === "off") return null;

      // Only restore an explicitly chosen preset. GPS coordinates are deliberately
      // not persisted between launches, so a previous GPS fix can never turn into
      // a misleading default marker after the app restarts.
      const savedPreset = localStorage.getItem("vedurspa-location-preset");
      if (!savedPreset) return null;
      return PRESET_LOCATIONS.find((loc) => loc.name === savedPreset) || null;
    } catch {
      return null;
    }
  });
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [currentCloudCover, setCurrentCloudCover] = useState<number>(15);
  const [cloudSourceLabel, setCloudSourceLabel] = useState<string>("staðaspá");
  const [stationCloudData, setStationCloudData] = useState<StationForecastData | null>(null);

  const activeImageRef = useRef<HTMLImageElement | null>(null);
  const playTimerRef = useRef<NodeJS.Timeout | null>(null);

  const requestId = useRef(0);

  // Fetch forecast data
  const loadForecast = useCallback(
    async (mode: Exclude<AppMode, "stadaspa">, category: string, refresh: boolean = false) => {
      const id = ++requestId.current;
      try {
        if (refresh) setIsRefreshing(true);
        else setIsLoading(true);
        setError(null);

        if (mode === "all4") {
          const json = await fetchDirectAll4Forecast(refresh);

          if (id !== requestId.current) return;
          if (!json) throw new Error("Ekki tókst að ná í 4-kortaspá");

          setAll4Data(json);
          setData({
            forecastMode: "all4",
            selectedCategory: "all4",
            title: json.title,
            frames: json.frames,
            total: json.frames.length,
            fetchedAt: json.fetchedAt,
            isCached: json.isCached,
            warning: json.warning,
            categories: [],
            all4: json,
          });

          if (!refresh && json.frames.length > 0) {
            const now = Date.now();
            let closestIdx = 0;
            let minDiff = Infinity;
            json.frames.forEach((f, i) => {
              const t = new Date(f.timestamp).getTime();
              const diff = Math.abs(t - now);
              if (diff < minDiff) {
                minDiff = diff;
                closestIdx = i;
              }
            });
            setCurrentIndex(closestIdx);
          } else if (json.frames.length > 0) {
            setCurrentIndex((prev) => Math.min(prev, json.frames.length - 1));
          }
        } else {
          const json = mode === "nordurljos"
            ? await fetchDirectAuroraForecast(category,refresh)
            : await fetchDirectWeatherForecast(category,refresh);

          if (id !== requestId.current) return;
          if (!json) throw new Error("Ekki tókst að ná í spágögn");

          setData(json);

          // Find closest frame to current time or keep current index
          if (!refresh && json.frames.length > 0) {
            const now = Date.now();
            let closestIdx = 0;
            let minDiff = Infinity;
            json.frames.forEach((f, i) => {
              const t = new Date(f.timestamp).getTime();
              const diff = Math.abs(t - now);
              if (diff < minDiff) {
                minDiff = diff;
                closestIdx = i;
              }
            });
            setCurrentIndex(closestIdx);
          } else if (json.frames.length > 0) {
            setCurrentIndex((prev) => Math.min(prev, json.frames.length - 1));
          }
        }
      } catch (err: any) {
        if (id !== requestId.current) return;
        console.error(err);
        setError(err.message || "Villa kom upp við að sækja gögn frá Veðurstofunni.");
      } finally {
        if (id === requestId.current) { setIsLoading(false); setIsRefreshing(false); }
        if(refresh)void preloadAllForecasts(reportOfflineMaps).catch(()=>{});
      }
    },
    []
  );

  useEffect(() => {
    if (forecastMode !== "stadaspa") loadForecast(forecastMode, selectedCategory);
  }, [forecastMode, selectedCategory, loadForecast]);

  const loadWarnings = useCallback(async () => {
    setWarningsLoading(true);
    try {
      const result = await fetchWeatherWarnings();
      setWarningsData(result);
      setWarningsError(null);
    } catch (err: any) {
      setWarningsError(err?.message || "Gat ekki sótt veðurviðvaranir");
    } finally {
      setWarningsLoading(false);
    }
  }, []);

  const loadNews = useCallback(async () => {
    setNewsLoading(true);
    try {
      const result = await fetchWeatherArticles();
      setNewsData(result);
      setNewsError(null);
    } catch (err: any) {
      setNewsError(err?.message || "Gat ekki sótt veðurfréttir");
    } finally {
      setNewsLoading(false);
    }
  }, []);

  useEffect(() => {
    // Reload once a minute while the app is open. This is separate from Android's
    // power-managed background checks (WorkManager minimum 15 min).
    let stopped = false;
    let busy = false;
    const run = async () => {
      if (stopped || busy) return;
      busy = true;
      try { await loadWarnings(); } finally { busy = false; }
    };
    void run();
    const timer = window.setInterval(() => { void run(); }, 60000);
    const onVisible = () => { if (document.visibilityState === 'visible') void run(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { stopped = true; window.clearInterval(timer); document.removeEventListener('visibilitychange', onVisible); };
  }, [loadWarnings]);

  useEffect(() => {
    if (warningsOpen && !newsData && !devArticles) void loadNews();
  }, [warningsOpen, newsData, devArticles, loadNews]);

  useEffect(() => {
    void configureWarningNotifications({
      enabled: appSettings.warningNotifications,
      minLevel: appSettings.warningNotificationMinLevel,
      hasLocation: !!userLocation,
      lat: userLocation?.lat,
      lon: userLocation?.lon,
      locationName: userLocation?.name,
    }).catch(() => {});
  }, [appSettings.warningNotifications, appSettings.warningNotificationMinLevel, userLocation]);

  const displayedWarningsData = useMemo(() => {
    if (appSettings.developerMode && devWarningLevel !== "off") return makeDevWarnings(devWarningLevel);
    return warningsData;
  }, [appSettings.developerMode, devWarningLevel, warningsData]);

  const enableWarningNotifications = useCallback(async () => {
    const granted = await requestWarningNotificationPermission().catch(() => false);
    if (!granted) {
      const next = { ...appSettings, warningNotifications: false };
      setAppSettings(next); writeAppSettings(next);
      alert("Tilkynningaleyfi var ekki veitt. Þú getur virkjað það síðar í Android stillingum.");
    }
  }, [appSettings]);

  const sendDevNotification = useCallback(async (level: WarningLevel) => {
    const granted = await requestWarningNotificationPermission().catch(() => false);
    if (!granted) { alert("Tilkynningaleyfi vantar."); return; }
    await sendWarningTestNotification(level).catch(() => alert("Ekki tókst að senda próftilkynningu."));
  }, []);

  // Numeric cloud cover from Staðaspá is the primary source for aurora
  // location scoring. It is far more reliable than inferring percentages from
  // antialiased map pixels and uses the same official forecast dataset.
  useEffect(() => {
    if (forecastMode !== "nordurljos" || !userLocation || stationCloudData) return;
    let cancelled = false;
    fetchStationForecastData().then(result => { if (!cancelled) setStationCloudData(result); }).catch(() => {});
    return () => { cancelled = true; };
  }, [forecastMode, userLocation, stationCloudData]);

  useEffect(() => {
    if (!appSettings.developerMode) {
      setDevWarningLevel("off");
      setDevArticles(false);
      setDeveloperOpen(false);
    }
  }, [appSettings.developerMode]);

  // Preload upcoming frames in all4 mode for instant scrubbing
  useEffect(() => {
    if (forecastMode !== "all4" || !all4Data || currentIndex < 0) return;
    const offsets = [1, 2, -1];
    offsets.forEach((offset) => {
      const idx = currentIndex + offset;
      if (idx >= 0 && idx < all4Data.frames.length) {
        const rImg = all4Data.rainFrames[idx]?.imageUrl;
        const hImg = all4Data.heatFrames[idx]?.imageUrl;
        const wImg = all4Data.windFrames[idx]?.imageUrl;
        if (rImg) preloadImage(rImg);
        if (hImg) preloadImage(hImg);
        if (wImg) preloadImage(wImg);
      }
    });
  }, [forecastMode, all4Data, currentIndex]);

  // Mode change handler
  const handleToggleForecastMode = (newMode: AppMode) => {
    if (newMode === forecastMode) return;
    if(newMode==="stadaspa")setStationMounted(true);
    setForecastMode(newMode);
    setIsPlaying(false);
    if (newMode === "nordurljos") {
      setSelectedCategory("skyjahula");
    } else if (newMode === "weather") {
      setSelectedCategory("urkoma");
    } else if (newMode === "all4") {
      setSelectedCategory("all4");
    }
  };

  // Cloud cover at the chosen location. Prefer the numeric N cloud field from
  // Staðaspá; only fall back to corrected pixel sampling if those values are not
  // available.
  const evaluateCurrentLocation = useCallback(() => {
    if (forecastMode !== "nordurljos" || !userLocation) return;
    const currentF = data && data.frames.length > 0 ? data.frames[currentIndex] : null;
    if (!currentF) return;

    const stationEstimate = estimateCloudAtLocation(stationCloudData, userLocation.lat, userLocation.lon, currentF.timestamp);
    if (stationEstimate) {
      setCurrentCloudCover(stationEstimate.percent);
      setCloudSourceLabel(stationEstimate.sourceLabel);
      return;
    }

    if (activeImageRef.current) {
      const { xPercent, yPercent } = coordsToMapPercent(userLocation.lat, userLocation.lon,'aurora');
      const cloud = sampleCloudCoverage(activeImageRef.current, xPercent, yPercent);
      setCurrentCloudCover(cloud);
      setCloudSourceLabel("skýjakort · varaleið");
    }
  }, [forecastMode, userLocation, data, currentIndex, stationCloudData]);

  const handleImageLoaded = (img: HTMLImageElement) => {
    activeImageRef.current = img;
    evaluateCurrentLocation();
  };

  useEffect(() => {
    evaluateCurrentLocation();
  }, [evaluateCurrentLocation, currentIndex, userLocation, stationCloudData]);

  // Request GPS. Android often returns a coarse/cached first fix, so keep
  // listening briefly and use the most accurate sample we receive.
  const handleRequestGps = async () => {
    setIsLocating(true);
    try {
      let permission = await Geolocation.checkPermissions();
      if (!locationAccess(permission).allowed) {
        const requested = await Geolocation.requestPermissions({ permissions: ["location"] });
        if (!locationAccess(requested).allowed) throw new Error("permission denied");
        permission = requested;
      }

      let bestPosition: Awaited<ReturnType<typeof Geolocation.getCurrentPosition>> | null = null;
      let watchId: string | null = null;
      let finished = false;

      await new Promise<void>(async (resolve) => {
        const finish = async () => {
          if (finished) return;
          finished = true;
          if (watchId) await Geolocation.clearWatch({ id: watchId }).catch(() => {});
          resolve();
        };

        const timeoutId = window.setTimeout(() => { void finish(); }, 9000);
        try {
          watchId = await Geolocation.watchPosition(
            { enableHighAccuracy: locationAccess(permission).precise, timeout: 10000, maximumAge: 0 },
            (position) => {
              if (!position || finished) return;
              if (!bestPosition || position.coords.accuracy < bestPosition.coords.accuracy) {
                bestPosition = position;
              }
              // 25 m is already much more precise than the map graphic itself.
              if (position.coords.accuracy <= 25) {
                window.clearTimeout(timeoutId);
                void finish();
              }
            }
          );
          if (finished && watchId) await Geolocation.clearWatch({ id: watchId }).catch(() => {});
        } catch {
          window.clearTimeout(timeoutId);
          void finish();
        }
      });

      if (!bestPosition) {
        bestPosition = await Geolocation.getCurrentPosition({
          enableHighAccuracy: locationAccess(permission).precise,
          timeout: 12000,
          maximumAge: 0,
        });
      }

      const pos = bestPosition;
      setUserLocation({
        name: locationAccess(permission).precise ? "Mín staðsetning (GPS)" : "Mín staðsetning (áætluð)",
        lat: pos.coords.latitude,
        lon: pos.coords.longitude,
        isGps: true,
        accuracy: Math.round(pos.coords.accuracy),
      });
      try {
        localStorage.setItem("vedurspa-location-enabled", "on");
        localStorage.removeItem("vedurspa-location-preset");
      } catch {}
    } catch (error) {
      alert(locationErrorMessage(error));
    } finally {
      setIsLocating(false);
    }
  };

  const handleDisableLocation = () => {
    setUserLocation(null);
    try {
      localStorage.setItem("vedurspa-location-enabled", "off");
      localStorage.removeItem("vedurspa-location-preset");
    } catch {}
  };

  const handleSelectLocation = (loc: UserLocation) => {
    setUserLocation(loc);
    try {
      localStorage.setItem("vedurspa-location-enabled", "on");
      localStorage.setItem("vedurspa-location-preset", loc.name);
    } catch {}
  };

  // Best time tonight is based on the real numeric cloud forecast at the
  // selected location for each dark frame (plus the forecast aurora activity).
  const bestTimeInfo = userLocation && data && data.frames.length > 0 && stationCloudData
    ? findBestAuroraFrameFromStations(data.frames, currentIndex, data.aurora?.byDate, stationCloudData, userLocation.lat, userLocation.lon)
    : null;

  // Stepping logic (single frame / 1 hour step)
  const handleStep = useCallback(
    (direction: number) => {
      if (!data || !data.frames.length) return;
      setCurrentIndex((prev) => {
        const next = prev + direction;
        if (next < 0) return 0;
        if (next >= data.frames.length) return data.frames.length - 1;
        return next;
      });
    },
    [data]
  );

  const handleStepBack = useCallback(() => {
    setIsPlaying(false);
    handleStep(-1);
  }, [handleStep]);

  const handleStepForward = useCallback(() => {
    setIsPlaying(false);
    handleStep(1);
  }, [handleStep]);

  const togglePlay = useCallback(() => {
    setIsPlaying((prev) => !prev);
  }, []);

  const jumpToClosestCurrentFrame = useCallback(() => {
    if (!data || !data.frames.length) return;
    const now = Date.now();
    let bestIndex = 0;
    let bestDiff = Number.POSITIVE_INFINITY;
    data.frames.forEach((frame, idx) => {
      const diff = Math.abs(new Date(frame.timestamp).getTime() - now);
      if (diff < bestDiff) {
        bestDiff = diff;
        bestIndex = idx;
      }
    });
    setIsPlaying(false);
    setCurrentIndex(bestIndex);
  }, [data]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key === "ArrowLeft") {
        e.preventDefault();
        handleStepBack();
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        handleStepForward();
      } else if (e.key === " ") {
        e.preventDefault();
        togglePlay();
      } else if (e.key === "Home") {
        e.preventDefault();
        setCurrentIndex(0);
      } else if (e.key === "End" && data) {
        e.preventDefault();
        setCurrentIndex(data.frames.length - 1);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleStepBack, handleStepForward, togglePlay, data]);

  // Autoplay animation loop
  useEffect(() => {
    if (!isPlaying || !data || !data.frames.length) {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
      return;
    }

    const intervalMs = Math.max(120, Math.round(500 / playbackSpeed));
    playTimerRef.current = setInterval(() => {
      setCurrentIndex((prev) => {
        if (prev >= data.frames.length - 1) {
          return 0; // Loop around
        }
        return prev + 1;
      });
    }, intervalMs);

    return () => {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    };
  }, [isPlaying, playbackSpeed, data]);

  const currentFrame = data && data.frames.length > 0 ? data.frames[currentIndex] : null;
  const currentTimestamp = currentFrame?.timestamp || "";

  // Synchronized frames for 4-map overview
  const rainFrame = useMemo(() => {
    if (!all4Data) return null;
    return findClosestFrame(all4Data.rainFrames, currentTimestamp);
  }, [all4Data, currentIndex, currentTimestamp]);

  const heatFrame = useMemo(() => {
    if (!all4Data) return null;
    return findClosestFrame(all4Data.heatFrames, currentTimestamp);
  }, [all4Data, currentIndex, currentTimestamp]);

  const windFrame = useMemo(() => {
    if (!all4Data) return null;
    return findClosestFrame(all4Data.windFrames, currentTimestamp);
  }, [all4Data, currentIndex, currentTimestamp]);

  const cloudFrame = useMemo(() => {
    if (!all4Data) return null;
    return findClosestFrame(all4Data.cloudFrames, currentTimestamp);
  }, [all4Data, currentTimestamp]);

  return (
    <div
      id="app-root"
      className="app-viewport overflow-hidden bg-slate-950 text-slate-100 font-sans flex flex-col justify-between selection:bg-emerald-600 selection:text-white"
    >
      {/* Top Header: Includes Mode toggle (Veður vs 4-Kort vs Norðurljós) and all Cloud categories */}
      <CompactHeader
        currentFrame={currentFrame}
        currentIndex={currentIndex}
        totalFrames={data?.frames.length || 0}
        categories={data?.categories || []}
        selectedCategory={selectedCategory}
        onSelectCategory={(catId) => {
          setSelectedCategory(catId);
          setIsPlaying(false);
        }}
        forecastMode={forecastMode}
        onToggleForecastMode={handleToggleForecastMode}
        onRefresh={() => {
          if (forecastMode === "stadaspa") setStationRefreshToken(v => v + 1);
          else {
            if (forecastMode === "nordurljos") setStationCloudData(null);
            void loadForecast(forecastMode, selectedCategory, true);
          }
        }}
        onOpenSettings={() => setSettingsOpen(true)}
        onOpenGuide={() => setGuideCenterOpen(true)}
        language={appSettings.language}
        isRefreshing={isRefreshing}
        headerTimestampOverride={forecastMode === "stadaspa" ? stationHeaderTimestamp : null}
      />


      <div id="shared-warning-slot" className="shared-warning-slot">
        {appSettings.showWarnings && displayedWarningsData && displayedWarningsData.warnings.length > 0 && (
          <WarningBanner warnings={displayedWarningsData.warnings} isCached={displayedWarningsData.isCached} onOpen={() => {setWarningFromBanner(true);setWarningsOpen(true);}} />
        )}
      </div>
      {/* Main Forecast Viewport */}
      {stationMounted && (
        <main id="main-station-stage" style={{display:forecastMode === "stadaspa"?"flex":"none"}} aria-hidden={forecastMode !== "stadaspa"} className="flex-1 min-h-0 overflow-hidden flex flex-col">
          <StationForecastPanel active={forecastMode === "stadaspa"} userLocation={userLocation} refreshToken={stationRefreshToken} developerMode={appSettings.developerMode} suspendOfficialMap={warningsOpen || settingsOpen || developerOpen} onSelectLocation={handleSelectLocation} onRequestGps={()=>void handleRequestGps()} isLocating={isLocating} onHeaderTimestampChange={setStationHeaderTimestamp} />
        </main>
      )}
      {forecastMode !== "stadaspa" && (
      <main id="main-forecast-stage" className="map-screen">
        <div className="shared-map-viewport">
          {forecastMode === "all4" ? (
            <All4MapsDisplay currentTimestamp={currentTimestamp} rainFrame={rainFrame} heatFrame={heatFrame} windFrame={windFrame} cloudFrame={cloudFrame} onStep={handleStep} onSelectMap={(category) => { if (category === "samsett") { setForecastMode("nordurljos"); setSelectedCategory("samsett"); } else { setForecastMode("weather"); setSelectedCategory(category); } }} isLoading={isLoading} />
          ) : (
            <MapDisplay currentFrame={currentFrame} frames={data?.frames || []} currentIndex={currentIndex} onStep={handleStep} onTogglePlay={togglePlay} isPlaying={isPlaying} isLoading={isLoading} error={error} onRetry={() => loadForecast(forecastMode as Exclude<AppMode, "stadaspa">, selectedCategory)} userLocation={userLocation} showLocationPin={forecastMode === "nordurljos" && selectedCategory !== "samsett"} isAuroraMode={forecastMode === "nordurljos"} onImageLoaded={handleImageLoaded} />
          )}
        </div>
        {forecastMode === "nordurljos" && (
          <NorthernLightsBar currentFrame={currentFrame} auroraData={data?.aurora} userLocation={userLocation} onSelectLocation={handleSelectLocation} onDisableLocation={handleDisableLocation} onRequestGps={handleRequestGps} isLocating={isLocating} cloudCoverPercent={currentCloudCover} cloudSourceLabel={cloudSourceLabel} bestTimeInfo={bestTimeInfo} onJumpToFrame={(idx) => { setCurrentIndex(idx); setIsPlaying(false); }} />
        )}
        <div className="map-controls">
        {offlineMaps && Boolean(offlineMaps.loading || offlineMaps.failed) && <div role="status" className="text-[10px] text-slate-400 text-center h-4">{offlineMaps.loading?`Sæki kort fyrir notkun án nets · ${offlineMaps.ready}/${offlineMaps.total}`:'Sum kort vantar fyrir notkun án nets'}</div>}
        <TimelineSlider language={appSettings.language} frames={data?.frames || []} currentIndex={currentIndex} onSelectIndex={(newIdx) => { setCurrentIndex(newIdx); setIsPlaying(false); }} />
        <HugeNavButtons language={appSettings.language} onStepBack={handleStepBack} onStepForward={handleStepForward} onTogglePlay={togglePlay} isPlaying={isPlaying} canStepBack={currentIndex > 0} canStepForward={data ? currentIndex < data.frames.length - 1 : false} playbackSpeed={playbackSpeed} onChangeSpeed={setPlaybackSpeed} onJumpToNow={jumpToClosestCurrentFrame} />
        </div>
      </main>
      )}

      {/* Ultra-compact Footer */}
      <footer id="app-footer" className="w-full max-w-4xl mx-auto px-2 py-0.5 text-center text-[9px] text-slate-500 border-t border-slate-900/80 shrink-0 hidden xs:block">
        Veðurstofa Íslands · Veðurkort · Staðaspá · Veðurviðvaranir
      </footer>

      {warningsOpen && <WarningsPanel focusFromBanner={warningFromBanner} data={displayedWarningsData} error={warningsError} loading={warningsLoading} newsData={newsData} newsError={newsError} newsLoading={newsLoading} developerArticles={appSettings.developerMode && devArticles} onClose={() => setWarningsOpen(false)} onRefresh={loadWarnings} onRefreshNews={loadNews} />}
      {settingsOpen && <AppSettingsPanel settings={appSettings} warningCount={displayedWarningsData?.warnings.length || 0} hasLocation={!!userLocation} onChange={(next) => { setAppSettings(next); writeAppSettings(next); }} onEnableNotifications={() => void enableWarningNotifications()} onOpenWarnings={() => {setWarningFromBanner(false); setSettingsOpen(false); setWarningsOpen(true); }} onOpenDeveloper={() => { setSettingsOpen(false); setDeveloperOpen(true); }} onOpenGuideCenter={() => { setSettingsOpen(false); setGuideCenterOpen(true); }} onClose={() => setSettingsOpen(false)} />}
      {developerOpen && appSettings.developerMode && <DeveloperPanel warningLevel={devWarningLevel} articleTest={devArticles} onWarningLevel={setDevWarningLevel} onArticleTest={setDevArticles} onSendTestNotification={(level) => void sendDevNotification(level)} onOpenWarnings={() => {setWarningFromBanner(false); setDeveloperOpen(false); setWarningsOpen(true); }} onClose={() => setDeveloperOpen(false)} />}

      {guideCenterOpen && <GuideCenter locale={appSettings.language} currentMode={forecastMode} onClose={() => setGuideCenterOpen(false)} onOpenTour={(kind) => { setGuideCenterOpen(false); setGuideKind(kind); }} onOpenBook={() => { setGuideCenterOpen(false); setGuideBookOpen(true); }} />}
      {guideBookOpen && <GuideBook locale={appSettings.language} onClose={() => setGuideBookOpen(false)} />}
      {guideKind && <GuidedTour kind={guideKind} locale={appSettings.language} onClose={()=>setGuideKind(null)} onMode={handleToggleForecastMode}/>}
      {/* Connectivity Banner */}
      <OfflineIndicator />
    </div>
  );
}
